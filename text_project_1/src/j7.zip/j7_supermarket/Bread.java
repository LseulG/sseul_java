package j7_supermarket;

public class Bread extends Product{
	Bread(){
		super.price = 1500;
	}
}
