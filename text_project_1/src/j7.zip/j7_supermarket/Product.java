package j7_supermarket;

public class Product {
	int price = 0; // ����
	
}
