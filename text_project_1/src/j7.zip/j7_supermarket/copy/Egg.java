package j7_supermarket.copy;

public class Egg extends Product{
	Egg(){
		super.price = 100;
	}
}
