package j7_supermarket.copy;

public class Bread extends Product{
	Bread(){
		super.price = 1500;
	}
}
