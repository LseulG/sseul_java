package j7_supermarket.copy;

public class Product {
	int price = 0; // ����
	
	
	
//	int num = 0; // ����
//	int total = 0; // �� ����
//	
//	Product(int price){
//		this.price = price;
//	}
//	
//	void cart(int num) {
//		this.num = num;
//		this.total = num * price;
//	}
	
}
