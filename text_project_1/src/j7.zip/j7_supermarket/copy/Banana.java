package j7_supermarket.copy;

public class Banana extends Product{
	Banana(){
		super.price = 1000;
	}	
}
