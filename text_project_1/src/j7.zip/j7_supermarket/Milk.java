package j7_supermarket;

public class Milk extends Product{
	Milk(){
		super.price = 2000;
	}
}
