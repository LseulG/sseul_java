package j7_supermarket;

public class Banana extends Product{
	Banana(){
		super.price = 1000;
	}	
}
