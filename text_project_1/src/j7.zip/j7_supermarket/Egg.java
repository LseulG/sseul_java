package j7_supermarket;

public class Egg extends Product{
	Egg(){
		super.price = 100;
	}
}
