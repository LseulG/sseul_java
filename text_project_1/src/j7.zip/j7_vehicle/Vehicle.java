package j7_vehicle;

public class Vehicle {
	void run() {
		System.out.println("veh �޸���.");
	}

}
