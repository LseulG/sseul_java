package j7_vehicle;

public class Bus extends Vehicle{
	@Override
	void run() {
		System.out.println("bus �޸���.");
	}
	
	void price() {
		System.out.println("bus price.");
	}
}
