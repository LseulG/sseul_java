package j7_vehicle;

public class Texi extends Vehicle{
	@Override
	void run() {
		System.out.println("texi �޸���.");
	}
	
	void price() {
		System.out.println("texi price.");
	}
}
