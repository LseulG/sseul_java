package j7_car;

public class CarEx {
	public static void main(String[] args) {
		Car car = new Car();
		for (int i=0; i<10; i++) {
			car.run();
		}
	}
}
