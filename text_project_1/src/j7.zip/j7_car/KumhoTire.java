package j7_car;

public class KumhoTire extends Tire {
	KumhoTire(String location,  int maxRotation){
		super(location,20);
	}
}
