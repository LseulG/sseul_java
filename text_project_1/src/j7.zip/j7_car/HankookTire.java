package j7_car;

public class HankookTire extends Tire{
	HankookTire(String location, int maxRotation){
		super(location,30);
	}
}
